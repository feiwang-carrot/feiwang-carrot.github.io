cellRelaxed: Code for NEDM
cellSDP: Code for SDR
cellLag: Code for FNEDM
-------------------------------------------------------------------------------------------------

1. Run 'performaceprofile.m' to generate errors of localizations by different methods.
2. Run 'performancegraph.m' to get the graph of the errors

