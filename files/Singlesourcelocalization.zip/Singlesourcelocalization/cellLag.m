function c_app = cellLag(x,D)
    %% cellLag(x,D) returns the position of the last cell in the EDM using tower positions to do facial reductions
    % Params: x, D
    % x: nxr-array of the sensor's position
    % D: EDM constructed by x and the missing cell
    
    % returns c_app = 2xr approximate positions of the cell using least
    % squares and procrustes
    %%
    [n,r] = size(x);
    J = eye(n+1)-ones(n+1)/(n+1);
    
    U = [x zeros(n,1);   
        zeros(1,r) 1];
    
    %%%%%%%%%%%%%%%%%%%%5
     %{
                P = x;
                ntemp = n ;
                V = [P zeros(ntemp,1);
                    zeros(1,r) 1];
                d = abs(getDelta(D,V,ntemp+1,r));
                [sortD, sortInd] = sort(d,'descend');
                quotes = sortD./([sortD(2:end); 1e-4]);
                indTemp = find(quotes>=1/(e+1e-4));
                if(~isempty(indTemp))
                    ind = sortInd(1:indTemp(1));
                else
                    ind = indTemp;
                end
                
                P(ind,:) = [];  % Delete towers with ind
                Pm = mean(P);
                P = P-ones(size(P,1),1)*Pm; % Translate cellphone back
                
                D = D(setdiff(1:ntemp+1,ind),:); %Removes rows with indexes i in deletedTowers
                D = D(:,setdiff(1:ntemp+1,ind)); % Removes colons with indexes i in deletedTowers
              keyboard;
                %} 
    %%%%%%%%%%%%%%%%%%%%%%%%
    cvx_begin quiet
        variable R(r+1,r+1) symmetric
        minimize(norm(getK(U*R*U',n+1)-D,'fro'))
    cvx_end

    if (min(eig(R))<0)
        cvx_begin sdp quiet
            variable Rp(r+1,r+1) symmetric
            minimize(norm(getK(U*Rp*U',n+1)-D,'fro'))
            subject to
                Rp >= 0
        cvx_end
        R = Rp;
        G = U*R*U';
        
        [U,S,~] = svd(J*G*J);
        Sb = S(1:r,1:r);
        P = U(:,1:r)*sqrtm(Sb);
        Pc = P-ones(n+1,1)*mean(P(1:n,:));
        
        Rt = Pc(1:n,:)\x; % Approximate transformation
        P_app = Pc*Rt; % Approximate positions with least squares
        c_app1 = P_app(end,:);

        C = Pc(1:n,:)'*x;
        [cU,~,cV] = svd(C);
        Rt = cU*cV'; % Approximate transformation
        P_app = Pc*Rt; % Approximate positions using Procrustes
        c_app2 = P_app(end,:);

        c_app = [c_app1; c_app2];
    else
        c = 1000;
        cvx_begin sdp quiet
            variable R0(r+1,r+1) symmetric
            minimize(norm(getK(U*R0*U',n+1)-D,'fro'))
            subject to
                R0 >= 0
        cvx_end
        Rk = R0;
        [q,v] = eig(Rk);
        qmin = q(:,1);
        Uk = qmin*qmin';
        err = v(1,1);
        T = 1;
        limit = 10;
        toler = 1e-10;
        while (err >= toler && T <= limit)
         cvx_begin sdp quiet
            variable Rn(r+1,r+1) symmetric
            minimize(1/2*square_pos(norm(getK(U*Rn*U',n+1)-D,'fro')) + c*trace(Uk*(Rn-Rk)))
            subject to
                Rn >= 0
        cvx_end
        Rk = Rn;
        [q,v] = eig(Rk);
        qmin = q(:,1);
        Uk = qmin*qmin';
       err = abs(v(1,1));
       T = T + 1;
        end
        
        R = Rk;
        G = U*R*U';
        
        [U,S,~] = svd(J*G*J);
        Sb = S(1:r,1:r);
        P = U(:,1:r)*sqrtm(Sb);
        Pc = P-ones(n+1,1)*mean(P(1:n,:));
        
        Rt = Pc(1:n,:)\x; % Approximate transformation
        P_app = Pc*Rt; % Approximate positions with least squares
        c_app1 = P_app(end,:);

        C = Pc(1:n,:)'*x;
        [cU,~,cV] = svd(C);
        Rt = cU*cV'; % Approximate transformation
        P_app = Pc*Rt; % Approximate positions using Procrustes
        c_app2 = P_app(end,:);

        c_app = [c_app1; c_app2];
        % c_app = cellLGN(x,D);
       % keyboard
    end
    
end
