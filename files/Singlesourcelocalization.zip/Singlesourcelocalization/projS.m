function Pi_S = projS(X,r)
    %% Pi_S(X,r) is the projection of X onto the cone of PSD matrices with rank<r
    % Params: X, r
    % X: A square matrix
    % r: maximum rank of matrix
    %%
    [P,D] = eig((X+X')/2);
    e = diag(D);
    [e, I] = sort(e,'descend');
    e(r+1:end) = 0;
    P = P(:,I);
    Pi_S = P*diag(max(0,e))*P';
end