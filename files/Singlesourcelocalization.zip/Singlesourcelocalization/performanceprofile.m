%%%%%%%%%%performance profile
nl =[ 7 12 16 ]; % number of towers
%el = [0.002,0.02,0.2]; % error factor;
el = [0.001,0.01,0.1]; 
%el = [0.0005, 0.001, 0.005, 0.01, 0.05, 0.15];
M = 5 ; % number of method
kr = 2; % number of outliers
r = 3; % Dimension
o = 3; % Outlier error
s = 100; % number of iterations

errors = zeros(s,M,length(nl),length(el)); 
stats = zeros(s,length(nl),length(el));
for k = 1:s
for i = 1:length(nl)
 n = nl(i);
for j = 1:length(el)
 e = el(j);  
[D, x] = generateData(n, r, e, kr, o);
P = x(1:n,:);
c = x(end,:);
Pm = 0;
%%%%%%%%%%%%%%% nearest EDM approxi with procruste
c_app = cellRelaxed(P,D);
%c_app = c_app+Pm;
c_app1 = c_app(1,:);
c_app1 = c_app1+Pm;
c_app2 = c_app(2,:);
c_app2 = c_app2+Pm;
err_relax_ls = norm(c_app1-c)/norm(c);
err_relax_pro = norm(c_app2-c)/norm(c);
%%%%%%%%%%%%%%%%%% GTRS
c_app = cellSDP(P,D);
c_app = c_app+Pm;
err_sdp = norm(c_app-c)/norm(c);   
%%%%%%%%%%%%%%%%%%%%%%%%facial reduction (LGD)
[x,Dn] = OutlierDet(P,D,e);
if size(x,1) < r
keyboard
end
c_app = cellLag(x,Dn);
c_app1 = c_app(1,:);
c_app1 = c_app1 + Pm;
c_app2 = c_app(2,:);
c_app2 = c_app2 + Pm;
err_lag_ls = norm(c_app1-c)/norm(c);  %% least squares
err_lag_pro = norm(c_app2-c)/norm(c); %% procrustes
%%%%%%%%%%%%%%%%%%%%%%%%weighted exposing vectors
%c_app = cellWEV(P,D);
%c_app1 = c_app(1,:);
%c_app1 = c_app1 + Pm;
%c_app2 = c_app(2,:);
%c_app2 = c_app2 + Pm;
%err_WEV_ls = norm(c_app1(1:2)-c(1:2))  /norm(c(1:2)); %%% least squares
%err_WEV_pro = norm(c_app2(1:2)-c(1:2))/norm(c(1:2)); %%% procrustes
%errors(k,:,i,j) = [err_relax, err_sdp,err_lag_ls, err_lag_pro, err_WEV_ls, err_WEV_pro];
errors(k,:,i,j) = [err_relax_ls,err_relax_pro,err_sdp,err_lag_ls, err_lag_pro];
stats(k,i,j) = NPeigen(P,D);
end
end
end 

save 'errorspf2outlier.mat'
keyboard;