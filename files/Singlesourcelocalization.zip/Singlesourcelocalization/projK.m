function P_K = projK(X,r)
    [n,~] = size(X);
    J = eye(n)-ones(n)./n;
    P_K = projS(J*X*J,r) + (X-J*X*J);
end