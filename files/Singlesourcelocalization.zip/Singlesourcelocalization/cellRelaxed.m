function c_app = cellRelaxed(x,D)
    [n,r] = size(x);
    J = eye(n+1)-ones(n+1,n+1)/(n+1);
        
    cvx_begin sdp quiet
        variable G(n+1,n+1) symmetric;
        minimize(fMinimize(G,D,n+1));
        subject to
            G >= 0
            sum(G) == zeros(1,n+1) 
    cvx_end
    
    %%%%%%%%%%%%%%%%%%majorization
        Gk = G;
        [q,v] = eig(Gk);
        Uk = zeros(n+1);
        for i = n+2-r:n+1
        qmin = q(:,i);
        Uk = Uk + (qmin*qmin');
        end
        Uk = eye(n+1)-Uk;
        err = sum(diag(v(1:n+1-r,1:n+1-r)));
        T = 1;
        c = 1000;
        limit = 10;
        toler = 1e-10;
  while (err >= toler && T <= limit)
         cvx_begin sdp quiet
            variable Gn(n+1,n+1) symmetric
            minimize(fMinimize(Gn,D,n+1)+ c*trace(Uk*(Gn-Gk)))
            subject to
                Gn >= 0
               sum(Gn) == zeros(1,n+1) 
        cvx_end
        Gk = Gn;
        [q,v] = eig(Gk);
        Uk = zeros(n+1);
        for i = r+1:n+1
        qmin = q(:,i);
        Uk = Uk + qmin*qmin';
        end
        err = abs(v(1,1));
        T = T + 1;
  end
    %%%%%%%%%%%%%%%%%%%%%%
    
    [U,S,~] = svd(J*Gk*J);
    Sb = S(1:r,1:r);
    Pt = U(:,1:r)*sqrtm(Sb); 
    Pc = Pt-ones(n+1,1)*mean(Pt(1:n,:));
    
    Rt = Pc(1:n,:)\x; % Approximate transformation
    P_app = Pc*Rt; % Approximate positions with least squares
    c_app1 = P_app(end,:);

    C = Pc(1:n,:)'*x;
    [cU,~,cV] = svd(C);
    Rt = cU*cV'; % Orthogonal Procrustes problem
    P_app = Pc*Rt; % Approximate positions
    c_app2 = P_app(end,:); % Approximate cell
    
    c_app = [c_app1; c_app2];
end
