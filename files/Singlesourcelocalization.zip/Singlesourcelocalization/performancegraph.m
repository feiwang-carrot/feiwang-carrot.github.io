% performance profile graph plot
errorsFile = load('errorspf1m.mat');
%errorsFile = load('errorspf2m.mat');

%Mat = errorsFile.Mat;
Mat = errorsFile.errors;
[l,m,n,s] = size(Mat);
%stats = errorsFile.stats;
% l number of iterations
% m number of different methods
% n number of different group of towers 
% s number of different error factors
% 1  neearest EDM 
% 2 SDP GTRS
% 3 facial reduction least square
% 4 facial reduction procruste
% 5 Weighted exposing vector least square
% 6 Weighted exposing vector procruste
e1 = zeros(1,n,s);
e2 = zeros(1,n,s);
e3 = zeros(1,n,s);
e4 = zeros(1,n,s);
e5 = zeros(1,n,s);
% e6 = zeros(1,n,s);
for i = 1:l
    for j = 1:n
        for k = 1:s
            e1(i,j,k) = Mat(i,1,j,k);
            e2(i,j,k) = Mat(i,2,j,k);
            e3(i,j,k) = Mat(i,3,j,k);
            e4(i,j,k) = Mat(i,4,j,k);
            e5(i,j,k) = Mat(i,5,j,k);
          %  e6(i,j,k) = Mat(i,6,j,k);
        end
    end
end
cc = zeros(m,n,s);  
rr = zeros(m,n,s);
%keyboard;
for i = 1:n
   for j = 1:s
       %indx = find(stats(:,i,j)==1);
      % indx = 1:100;
        for k = 1:m
        %   cc(k,i,j) = mean(Mat(indx,k,i,j));
           cc(k,i,j) = mean(Mat(:,k,i,j));
        end  
   end
end  
%keyboard
for k = 1:m
    for i = 1:n
        for j = 1:s
       rr(k,i,j) = cc(k,i,j)/min(cc(:,i,j));
        end
    end
end
phi= zeros(m,200);
for k = 1:m
    temp = reshape(rr(k,:,:),n*s,1);
    for tt = 1:200
       phi(k,tt) = sum(temp<1+tt*0.001);
    end
end
%figure(1)
plot(1:200,phi(1,:),'b-');
xlim([1 200])
xticks([1 20 40 60 80 100 120 140 160 180 200])
hold on
plot(1:200,phi(2,:),'r-');
hold on
plot(1:200,phi(3,:),'g-');
hold on
plot(1:200,phi(4,:),'y-');
hold on
plot(1:200,phi(5,:),'k-');
%hold on
%plot(phi(6,:),'c-');
hold off
legend('L-NEDM','P-NEDM','SDR','L-FNEDM','P-FNEDM')


% hold on 
% plot(phi(4,:),'b*')
% hold on
% plot(phi(5,:),'r*')
% hold on
% plot(phi(6,:),'g*')
% hold off
keyboard

