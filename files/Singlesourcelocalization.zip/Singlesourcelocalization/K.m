function D=K(B)
%function D=K(B)
e=ones(size(B,1),1);
D=diag(B)*e'+e*((diag(B))')-2*B;    % D from B
