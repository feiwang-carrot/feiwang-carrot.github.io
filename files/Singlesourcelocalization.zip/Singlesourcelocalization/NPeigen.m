function stat = NPeigen(x, D)

  %%
    [n,r] = size(x);
    
    U = [x zeros(n,1);   
        zeros(1,r) 1];

    cvx_begin quiet
        variable R(r+1,r+1) symmetric
        minimize(norm(getK(U*R*U',n+1)-D,'fro'))
    cvx_end

    if (min(eig(R))<0)
     stat = 1;   
    else
     stat = 0;
    end

end