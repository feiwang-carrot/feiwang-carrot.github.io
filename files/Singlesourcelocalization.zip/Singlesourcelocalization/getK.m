function K = getK(G,n)
    %% getK(G,n) returns the Lindenstrauss mapping of G
    % Params: G, n
    % G: A Gramian matrix
    % n: size of the matrix
    %%
    K = G;
    for i = 1:n
        for j = 1:n
            K(i,j) = G(i,i) + G(j,j) - 2*G(i,j);
        end
    end
end