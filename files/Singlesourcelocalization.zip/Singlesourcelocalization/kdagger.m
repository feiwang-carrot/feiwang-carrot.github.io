function k = kdagger(D)
    %% kdagger(D) returns the Moore-Penrose inverse of D
    % Params: D
    % D: An EDM matrix
    n = size(D);
    J = eye(n)-ones(n)*(1/n(1));
    k = -J*(D-diag(diag(D)))*J/2;
end