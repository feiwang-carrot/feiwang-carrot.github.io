clc, clear, close all
% 1-dim: index of generated data iteration
% 2-dim: index of methods
% 3-dim: number of towers
% 4-dim: error ratio
errorsFile = load('errors');
errors = errorsFile.errors;

%% Graphs for magnitude of error
e = [0.05, 0.10, 0.25, 0.5]; % Change accordingly
%e = 0.05;
[s,~,n,~] = size(errors);

temp = errors(:,:,end,1:length(e)); % Compare magnitude of error with most towers (3rd index to change #towers)
temp = reshape(temp,[s,8,n]); % Reshape for nanmean
temp = permute(nanmean(temp,1),[3,2,1]); % Reshape for plot

figure
plot(e,temp);
xlabel('Magnitude of error');
ylabel('Mean relative error (%)');
legend('RNEDM','SDR','LRFR-NEDM','PRFR-NEDM',...
    'L-LGD','P-LGD', 'L-WEV', 'P-WEV');

%% Graphs for varying towers
n = 5:5:20; % Change accordingly

temp = errors(:,:,1:length(n),1); % Last index to change magnitude of error
temp = permute(nanmean(temp,1),[3,2,1]); % Reshape for plot

figure
plot(n,temp);
xlabel('Number of towers');
ylabel('Mean relative error (%)');
legend('RNEDM','SDR','LRFR-NEDM','PRFR-NEDM',...
    'L-LGD','P-LGD', 'L-WEV', 'P-WEV');
