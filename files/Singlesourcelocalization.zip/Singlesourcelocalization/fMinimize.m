function y = fMinimize(G,D,n)
    K = G;
    for i = 1:n
        for j = 1:n
            K(i,j) = G(i,i) + G(j,j) - 2*G(i,j);
        end
    end
    y = norm(K-D,'fro');
end