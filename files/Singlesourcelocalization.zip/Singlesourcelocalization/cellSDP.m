function c_sdp = cellSDP(x,D)
    %% cellSDP(x,D) returns the position of the last cell in the EDM using SDPR
    % Params: x, D
    % x: nxr-array of the sensor's positions
    % D: EDM constructed by x and the missing cell
    
    %%
    [n,r] = size(x);
    A = [-2*x,ones(n,1)];
    b = D(1:n,end)-sum(x.^2,2);
    f = [zeros(r,1); -0.5];
    
    Q = [A'*A -A'*b;
         -b'*A b'*b];
    F = [eye(r) zeros(r,1);
         zeros(1,r) 0];
    C = [F f;
         f' 0];

    cvx_begin sdp quiet
        variable Y(r+1 + 1, r+1 + 1) symmetric;
        minimize(trace(Q'*Y))
        subject to
            Y >= 0;
            Y(r+2,r+2) == 1;
            trace(C'*Y) == 0;
    cvx_end
    
    c_sdp = Y(1:r,r+2)';
end