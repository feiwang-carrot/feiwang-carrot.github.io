function sumBt = getSumBt(x,n,Bt)
    [~,m] = size(Bt);
    sumBt = zeros(n);
    for i = 0:m-1
       Bit = Bt{i+1};
       sumBt = sumBt + Bit(x(1+n*i:n*(i+1)));
    end
end