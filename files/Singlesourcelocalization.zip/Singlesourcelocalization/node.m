classdef node
    properties
       Wi
       i
    end
    methods
    end
end
