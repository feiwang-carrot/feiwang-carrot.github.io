function y = f(R,D,x)
    %% f(.) serves as a help function for a minimization problem
    % Params: R, D, x
    % R: Matrix to minimize
    % D: EDM constructed by x and the missing cell
    % x: nxr-array of the sensor's positions
    
    % returns y = objectiveFunction
    %%
    [n,r] = size(x);
    Pc = x(1:n,:);
    T = [Pc zeros(n,1);
        zeros(1,r) 1];
    G = T*R*T';
    K = G;
    for i = 1:n+1
        for j = 1:n+1
            K(i,j) = G(i,i) + G(j,j) - 2*G(i,j);
        end
    end
    y = norm(K-D,'fro');
end