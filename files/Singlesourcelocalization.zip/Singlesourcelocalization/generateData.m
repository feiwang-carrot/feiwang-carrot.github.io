function [D,x,outliers] = generateData(n,r,e,k,o)
    %% generateData(.) returns a set of random points with corresponding EDM and outliers
    % Params: n, r, e, k, o
    % n: Number of sensors
    % r: Dimension
    % e: Relative error factor 0<e<1
    % k: Number of outliers
    % o: outlier error
    
    % Returns : D, x, outliers
    % D: EDM
    % x: nxr set of random points, with the last row being the cell
    % outliers: nx1 boolean vector refering to which sensors are outliers
    %%
    xtemp = rand(n,r);
    x = xtemp-ones(n,1)*mean(xtemp);
    c = rand(1,r);
    x = [x; c];

    D = zeros(n+1,n+1);
    for i = 1:n+1
        for j = 1:n+1
            D(i,j) = (norm(x(i,:)-x(j,:))*(1 + e*2*(rand - 0.5)*double(eq(j,n+1))))^2;
        end
    end

    p = randperm(n);
    D(p(1:k),end) = D(p(1:k),end).*(o*(rand(k,1)+1)); % Outlier factor between (o,2*o)
    D(end) = 0;
    D = (D+D')/2;
    
    outliers = zeros(n,1);
    outliers(p(1:k)) = 1;
end