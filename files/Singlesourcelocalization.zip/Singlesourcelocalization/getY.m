function Y = getY(xS,D,V,r)
    [n,m] = size(V);
    J = eye(n) - ones(n)/n;
    A_t = @(x) diag(x);
    B_t = cell(1,m);
    for ii = 1:m
       B_t{ii} = @(x) J*V(:,ii)*(J*x)';
    end
    g = @(x) -D+A_t(x(1:n))+getSumBt(x(n+1:n+m*n),n,B_t)+getSumCt(x(n+m*n+1:end),n,B_t);
    f = @(x) projK(g(x),r);
    Y = -f(xS);
end