function sumCt = getSumCt(x,n,Bt)
    [~,m] = size(Bt);
    sumCt = zeros(n);
    for i = 0:m-1
       Bit = Bt{i+1};
       sumCt = sumCt + Bit(x(1+n*i:n*(i+1)))';
    end
end