function [x,Dn] = OutlierDet(P,D,e)

              %  P = x;
               [n,r] = size(P);
                ntemp = n ;
                V = [P zeros(ntemp,1);
                    zeros(1,r) 1];
                d = abs(getDelta(D,V,ntemp+1,r));
               % [sortD, sortInd] = sort(d,'descend');
                %quotes = sortD./([sortD(2:end); 1e-4]);
                %indTemp = find(quotes>=100/(e+1e-4));
                %if(~isempty(indTemp))
                %    ind = sortInd(1:indTemp(1));
               % else
                %    ind = indTemp;
                %end
                d = d/norm(d);
                 ind = find(d >= 1/sqrt(n));
                P(ind,:) = [];  % Delete towers with ind
                Pm = mean(P);
                P = P-ones(size(P,1),1)*Pm; % Translate cellphone back
                
                Dn = D(setdiff(1:ntemp+1,ind),:); %Removes rows with indexes i in deletedTowers
                Dn = Dn(:,setdiff(1:ntemp+1,ind)); % Removes colons with indexes i in deletedTowers
            % Dn = D;
             x = P;

 % keyboard;
end