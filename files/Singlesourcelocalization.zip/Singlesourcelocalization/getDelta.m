function delta = getDelta(EDM,V,n,r)
   
   cvx_begin quiet sdp
        variable d(n,n)  symmetric;
        variable R(r+1,r+1) symmetric;
        minimize(norm(d(:),1))
        subject to
            d == EDM-getK(V*R*V',n)
            R >= 0;
   cvx_end
   % Check consecutive ratios as larger than 1/e, when there is a sudden
   % drop stop.
   delta = d(1:n-1,end);
end