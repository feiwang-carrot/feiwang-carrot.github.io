%profile clear
 %% Initialize
clearvars
%profile on
mkdir('RPCA_GD')
addpath(genpath('RPCA_GD'))
r = 2; % target rank for generating the data
densityS = 0.01;   % density for S(sampled) in Z=L+S for generating the data
numProbs = 10;    % number of problems
filename = 'table_noiseless.tex';
%filenamealm = 'table_noiseless26alm.tex';
%%%% do we have all these variables?????
opts.verbose = 0;
opts.maxsize = 10*(r+1)+20;
%opts.itergrow = 5;
opts.orig = 0; % set to 1 to use the original low rank for testing 
opts.tolrankp = 1e-8;
opts.tolrankq = 1e-8; % tolerance for rank to get exposing vectors.
opts.randseed = 1;
opts.fr = 1; % facial reduction
opts.alm = 0; % alternating
opts.gd = 1; % gradient descent
rng shuffle
rng(11);
%opts.seed = randi(1000); % seed for random data
%opts.muu = 3; % muu for the L + muu*S  ???????? need as function of m,n???
opts.redrank = 0; % 1 then reduce the rank of exposing vector by 1
opts.densityS = densityS;
opts.tolpalm = 1e-8;   
opts.palmlimit = 500;
opts.palmretol = 1e-3;
opts.noiselevel = 0;
opts.model = 1; % model 0 means only low rank model 
opts.spn = 1; % 1 means nullspace for sparse matrix
opts.apv = 0; % 0 means not using previous recovered data for the exp. vector Yfinal

%%% Small problems, increasing size
nn = [800;1000;1200;1500;1800;2100;3000;5000]; % size of each problem not change
mm = [800;1000;1200;1500;1800;2100;3000;5000];%1200;1500;1800;2100]; % size of each problem not change
minclique = [r+3;r+3;r+3;r+3;r+3;r+3;r+3;r+3];
itergrow = [5,5,5,5,1,5,1,0];
PP = [0.2;0.2;0.2;0.2;0.2;0.2;0.2;0.2]; % density for the sampled data
%muu = [1./(0.2.*sqrt(nn));]%10;15;15;15;];
muu = [0.88;0.79;0.29;0.26;0.12;0.11;0.09;0.07];

%% Run tests

%%%%%%%%%%%%%%%Data generating for ALM comparison


Rrun_testnoiseless(r, densityS, nn, mm,minclique, itergrow, PP, muu,numProbs, filename, opts);
%profile report
 %%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%
%%%%% Compare with nonconvex gradient descent

 
%profile on


 


