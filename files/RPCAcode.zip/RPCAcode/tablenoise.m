  %profile clear
 %% Initialize
clearvars
%profile on

r = 2; % target rank for generating the data
densityS = 0.01;   % density for S(sampled) in Z=L+S for generating the data
numProbs = 1;    % number of problems
filename = 'table_noise.tex';
%filenamealm = 'table_noiseless26alm.tex';
%%%% do we have all these variables?????
opts.verbose = 0;
opts.maxsize = 10*(r+1)+20;
%opts.itergrow = 5;
opts.orig = 0; % set to 1 to use the original low rank for testing 
opts.tolrankp = 1e-8;
opts.tolrankq = 1e-8; % tolerance for rank to get exposing vectors.
opts.randseed = 1;
opts.fr = 1;
opts.alm = 1;
rng shuffle
rng(11);
%opts.seed = randi(1000); % seed for random data
%opts.muu = 3; % muu for the L + muu*S  ???????? need as function of m,n???
opts.redrank = 0; % 1 then reduce the rank of exposing vector by 1
opts.densityS = densityS;
opts.tolpalm = 1e-4;   
opts.palmlimit = 500;
opts.palmretol = 1e-3;
opts.noiselevel = 1e-4;
opts.model = 1; % model 0 means only low rank model 
opts.spn = 1; % 1 means nullspace for sparse matrix
opts.apv = 0; % 0 means not using previous recovered data for the exp. vector Yfinal

%%% Small problems, increasing size
nn = [600,800,1000,1500,2000]; % size of each problem not change
mm = [600,800,1000,1500,2000];%1200;1500;1800;2100]; % size of each problem not change
minclique = [r+3,r+3,r+3,r+3,r+3;];
itergrow = [1,1,1,1,1]; % number of iterations to compute cliques
PP = [0.4,0.4,0.3,0.3,0.3]; % density for the sampled data
muu = [1./(0.2.*sqrt(nn));]%10;15;15;15;];
%muu = [0.88];

%% Run tests

%%%%%%%%%%%%%%%Data generating for ALM comparison


Rrun_testnoise(r, densityS, nn, mm,minclique, itergrow, PP, muu,numProbs, filename, opts);
%profile report
 %%%%%%%%%%%%%%   %%%%%%%%%%%%%
 %%%%%%%%%%%%%%
 
%profile on


 


