function [lowranksucc, r] = rankDec(X,rl,rr,opts, densityS,iterlimit)
%%%% This code uses a range for the rank and detects an appropriate
%%%     target rank using a submatrix of the data.
%%INPUT:
%%%%% X the submatrix
%%%%%%%%%% [rl rr] range of rank given
%%%% densityS of the sparse noise of the data
%%% output:   r is the estimate of the rank

[lr,lc] = size(X);
lowranksucc = false;
for r = rl:rr
    
   sk = 1/(lr*lc);
   skmax = max(densityS,sk);
   dsk =  1/(lr*lc);
   while  sk <= skmax + 0.000001&& lowranksucc == false
       [L1,S1] = PALM(X,X,0,r,sk,opts.tolpalm,iterlimit,opts);   
        [uXtemp,tempsvd,vXtemp]=svd(L1);
       if abs(tempsvd(r+1,r+1))<lr*lc*opts.tolpalm && norm(S1-round(S1))< 0.5
       lowranksucc = true;
       end
       sk = sk+ dsk; 
   end
   if lowranksucc == true
    break;
   end
end

if ~lowranksucc
	   fprintf('lowrank detection failed in file rankDec.m \n')
end
end
