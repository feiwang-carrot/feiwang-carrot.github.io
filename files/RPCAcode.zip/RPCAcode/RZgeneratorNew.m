function [Zorig,Zpart,Lorig,Sorig,inds,noiseN] = RZgeneratorNew(params)
%        [Zorig,Zpart,Lorig,Sorig,inds,noiseN] = RZgeneratorNew(params)
% Zgenerator returns a m by n partial matrix Zpart with 
%   approx. percentage p elements known and the full original
%   random generated matrix Zorig of rank r.
%  Uz,Vz,ds are the r left/right singular vectors and sing. values, resp.
m=params.m;
n=params.n;
r=params.r;
D=params.D;
p=params.p;
if isfield(params,'noiselevel') % NEWNEWNEW
    noiselevel=params.noiselevel;
else
    noiselevel = 0;  
end
seed=params.seed;
 %rng('default')
rng(seed); % NEW
saverng=rng; % NEW
save('currentrng.mat','saverng') % NEW

%%%%%%%%%%%%%change to integer data july25/17
P = 4*randn(m,r);
P(abs(P)<1)=P(abs(P)<1)+2;
Q = 4*randn(r,n);
Q(abs(Q)<1)=Q(abs(Q)<1)+2;
%P = randi(8,m,r);
%Q = randi(8,r,n);
P = round(P); %% % assume integers data
Q = round(Q); %% assume integers data
Lorig = P*Q; % Lorig should be rank r

inds=find(sprandn(m,n,p));   % for the sampling indices - uniform distr??
Sorig=spalloc(m,n,length(inds));  % D density for sampled els
temp = 10*sprandn(length(inds),1,D); % 10 parameter??? for mean error???
%%%%% lift to nonzero integer values for sparse/outliers
%keyboard
temp(temp<0)=-ceil(-temp(temp<0));
temp(temp>0)=ceil(temp(temp>0));

%%%%%%%%%%%%%%%%
%%%%% lift to nonzero integer values for sparse/outliers
%temp(abs(temp)<1)=sign(temp(abs(temp)<1));
%%%%%%%%%%%%%%%%
Sorig(inds) = temp; % sparse S in Z=L+S
Zorig=Lorig+Sorig;
Zpart=spalloc(m,n,length(inds));

%%%%%%%%%%%%%%%the remainder of this file is NOT used for nonoise cases!!
if noiselevel>0,
    magnitude = norm(Zorig(inds),1)/length(inds);
	Noise=noiselevel*magnitude*randn(length(inds),1);
	Zpart(inds)=Zorig(inds)+Noise;
else
	Zpart(inds)=Zorig(inds);
	Noise=0;
end
noiseN=norm(Noise,1);

end  % end of function

