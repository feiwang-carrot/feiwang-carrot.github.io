   function   x=localsvec(X,indsu,indsuu)
%  function   x=svec(X);
%  Use the isometry version
%n=size(X,1);
%E=ones(n);
%indsu=find(triu(E,0));
%indsuu=find(triu(E,1));
X(indsuu)=sqrt(2)*X(indsuu);
x=X(indsu);
