clear
%%%%%%%%%%test target rank algorithm
%%%%%%%%% This algorithm tests the ability to detect rank
%%%%%%%%  given a range for the rank and a submatrix
%%%%%%   The actual code called  below is
%%%%         rankDec(Zorig,rl,rr,opts, 2*densityS,iterlimit)
%%%%
%filename = 'table_targetrank.tex'; % file name for the tables
opts.tolpalm = 1e-4;   
opts.palmlimit = 500;  % iteration limit
opts.palmretol = 1e-3;
opts.verbose = 0;
densityS = 0.01;
iterlimit = opts.palmlimit;
noiselevel =  1e-5;
%%% mm  is rows;   nn is cols
mm = [10,15,20];%1200;1500;1800;2100]; % size of each problem not  rows
nn = [10,15,20]; % size of each problem not change cols
 r = 2;   % target rank
 L = length(mm);   % length of the data
 D = densityS;
 successrate = zeros(L,1);
for i = 1:L   % for loop for  various sizes of data
    m = mm(i);  % rows
    n = nn(i);  % cols
 rt = zeros(1,100);   % saving the ranks
lowranksucc = false(1,100);   % saving the success/failures
 for j = 1:100   % for loop for number of cases
%   generate data using   P*Q for low rank part
P = 4*randn(m,r);
P(abs(P)<1)=P(abs(P)<1)+2;
Q = 4*randn(r,n);
Q(abs(Q)<1)=Q(abs(Q)<1)+2;
%P = randi(8,m,r);
%Q = randi(8,r,n);
%P = round(P); %% % assume integers data
%Q = round(Q); %% assume integers data
Lorig = P*Q; % Lorig should be rank r for the low rank part

Sorig = 10*sprandn(m,n,D); % 10 parameter??? for mean error???
%%%%% lift to nonzero integer values for sparse/outliers
%keyboard
%temp(temp<0)=-ceil(-temp(temp<0));
%temp(temp>0)=ceil(temp(temp>0));

%%%%%%%%%%%%%%%%
%%%%% lift to nonzero integer values for sparse/outliers
%temp(abs(temp)<1)=sign(temp(abs(temp)<1));
%%%%%%%%%%%%%%%%
Zorig=Lorig+Sorig;

%%%%%%%%%%%%%%%%%not needed?
%%%%%%%%%%%%%%%the remainder of this file is NOT used for nonoise cases!!
%%%if noiselevel>0,
%%%    magnitude = norm(Zorig(inds),1)/length(inds);
%%%	Noise=noiselevel*magnitude*randn(length(inds),1);
%%%	
%%%else
%%%	Noise=0;
%%%end
%%%%%%%%%%%%%%%%%not needed?
%%%% range for rank
rl = max(1,r-1);
rr = r+3;
rs = zeros(rr-rl+1,1);
%%%%  call the main code for RPCA
[lowranksucc(j),rt(j)] = rankDec(Zorig,rl,rr,opts, 2*densityS,iterlimit);  
 end   % for loop for number of cases
 plot(rt,'x')
 axis([1 length(rt) min(rt)-1 max(rt)+5])
 hold on
 hold off
 fprintf('number of failures for detect rank is %i \n',...
               sum(~lowranksucc))
 successrate(i) =  length(find(rt == r))/100;
      for k = rl:rr
          rs(k) = length(find(rt == k))/100;
      end
  keyboard
end   % for loop for sizes
 