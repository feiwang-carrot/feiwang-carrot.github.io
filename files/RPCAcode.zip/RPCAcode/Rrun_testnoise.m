function  Rrun_testnoise(r, densityS, nn, mm,minclique,itergrow,PP,muu, numProbs, filename, opts)
%         Rrun_testnoiseless(r, D, nn, mm, NF, PP, numProbs, filename, opts)
% r is rank of L in Z=L+S
% D is density of S in Z=L+S


num_fullcomplete = zeros(length(nn), numProbs);
rank_init        = zeros(length(nn), numProbs);
resid_init       = zeros(length(nn), numProbs);
resid_initalm       = zeros(length(nn), numProbs);
prerefine_time   = zeros(length(nn), numProbs);
prerefinealm_time   = zeros(length(nn), numProbs);
densities        = zeros(length(nn), numProbs);
num_fullcompletealm = zeros(length(nn), numProbs);
%resid_init       = zeros(length(nn), numProbs);
%prerefine_timealm   = zeros(length(nn), numProbs);
%percentsrecoverd = zeros(length(nn), numProbs);
rv        = zeros(length(nn), numProbs);



for ll = 1:length(nn)
    
    params.m    = mm(ll);
    m=params.m;
    params.n    = nn(ll);
    n=params.n;
    params.r    = r; % desired rank for incomplete Z and for complete Y/target rank
    params.D    = densityS; % desired density for S part of Z=L+S 
    params.tolerrank = max(m,n)*1e8*eps; % change below after Zpart
   
        params.noiselevel  = opts.noiselevel; % noise level related to the magnitude of the entries
    
    params.p    = PP(ll);   % percent known elements in L
    params.minclique = minclique(ll);
    params.muu = muu(ll);
    params.itergrow = itergrow(ll);
   % seeds = randperm(numProbs)
    randp = randperm(100);
    seeds = randp(1:numProbs);
    %%%%% take average over numProbs (done in the end) %%%%
    TimeMC = 0;
    for pp=1:numProbs %%% so this is to test numProbs for each test class
        
        % params.seed = opts.seed;
        if opts.randseed == 1
       %  rng shuffle
         params.seed = seeds(pp);
        else
         params.seed = opts.seed;    
        end
       %params.seed = 'shuffle';  % parameter for rng(seed)
       
        if opts.verbose
            disp('-------------------------------------------------');
            disp(params);
        end
        %%%% generating data
         [Zorig,Zpart,Lorig,Sorig,indsZ,realNoise]= RZgeneratorNew(params);
      
    if opts.fr == 1
	% generate random problem and solve
       problem.Zorig=Zorig;
       problem.Lorig=Lorig;
       problem.Sorig=Sorig;
       problem.Zpart=Zpart;
       problem.indsZ=indsZ;
       %%%% realNoise not used for nonoise cases??????
       problem.realNoise=realNoise;   %%%what is this???input and output???
       %% solve the problem
       %try
       [flag,resids,time1,density] = ...
            RcompleteZ(params,opts,problem);
       %catch
         %  flag = 1;
         %  fprintf('failure, RcompleteZ exit unexpectedly \n')
       %end
       
        if flag == 0    % if it is properly solved
            num_fullcomplete(ll,pp) = 1;
            rank_init(ll,pp)        = r;
            resid_init(ll,pp)       = resids(1); 
            prerefine_time(ll,pp)   = time1;
            rv(ll,pp)               = 0; % rn;
            densities(ll,pp)=density;
        else
            num_fullcomplete(ll,pp) = 0;
        end
        
        %rcvrd(ll,pp)            = ps;
     %   rcvrd(ll,pp)            = resids(2);  % changed by henry jan1/18
       
    end
       if opts.alm == 1
       Xs = Lorig;
      Omega = indsZ;
       Omega_c = setdiff(1:m*n,indsZ);
     Sorig = full(Sorig);
      OmegaY= find(Sorig);
      Ys = Sorig;
      D = Xs + Ys; 
      b = D(Omega);
      opts1.b = b; 
      opts1.OmegaY = OmegaY; 
      opts1.Omega_c = Omega_c;
      opts1.Omega = Omega;
      opts1.mu = norm(b)/1.25;
      opts1.Xs = Xs;  opts1.Ys = Ys;
      opts1.n1 = m; opts1.n2 = n;
      % % opts.mu = norm(D)/1.25;
     % opts.mu = norm(b)/1.25;
     opts1.sigma = 1e-6; opts1.maxitr = 100; opts1.rho = 1/sqrt(m); 
     opts1.eta_mu = 2/3; opts1.eta_sigma = 2/3;
% opts.muf = opts.mu*1e-7;
      opts1.muf = 1e-6;
      opts1.sigmaf = 1e-6;  
      opts1.epsilon = 1e-7;
      opts1.sv = 100;
     starttime = cputime; 
     out = ALM_Mat_Comple_v3(opts1.b, opts1.Omega, opts1); 
     time_MC = cputime-starttime; 
     %TimeMC = TimeMC + time_MC;
       fprintf('*******************************************************************\n');
%%%%%%%%% print stats %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fprintf('*******************************************************************\n');
      if norm((out.X)-Lorig,'fro')/norm(Lorig,'fro') >= 1
      flagalm = flag;
      else
        flagalm = flag;
      end
       resid_initalm(ll,pp)  = norm((out.X)-Lorig,'fro')/norm(Lorig,'fro');
        prerefinealm_time(ll,pp)   = time_MC;
       if flagalm == 0    % if it is properly solved
            num_fullcompletealm(ll,pp) = 1;
        else
            num_fullcompletealm(ll,pp) = 0;
       end
       end
       
       %percentsrecoverd(ll,pp)  = ps; 
       %fprintf('%g  percent recovered  \n',ps)

    end   
end

%allLocalized=true;   % should include the number of failures in the table

fmt1 = '%5.0f & %5.0f & %5.2f &';

% if allLocalized
%     fmt2 = '';
% else
%     fmt2 = '%9.1f & ';
% end

fmt3 = '%7.2f & %7.2f & %7.2f & %7.2f & %5.0f & %s & %s';
fmt4 = ' \\cr\\hline\n';
fmt5 = '\\cr\\cline{1-3}\n';

hfmt1 = regexprep(fmt1, '(\.[0-9])*[def]', 's');
%hfmt2 = regexprep(fmt2, '(\.[0-9])*[def]', 's');
hfmt3 = regexprep(fmt3, '(\.[0-9])*[def]', 's');

fid = fopen(filename, 'w');

fprintf(fid, '%s\n', '\begin{tabular}{|ccc||c|c|c|c|c|c|c|} \hline');
fprintf(fid, '%s', [...
    '\multicolumn{3}{|c||}{Specifications} & ', ...
    '\multirow{2}{*}{success fr \% } & ', ...
    '\multirow{2}{*}{success ALM \%} & ', ...
    '\multirow{2}{*}{Time fr (s)} &', ...
    '\multirow{2}{*}{Time ALM (s)} &', ...
    '\multirow{2}{*}{Rank} &', ...
    '\multirow{2}{*}{Res ($FR$)} &'...
    '\multirow{2}{*}{Res ($ALM$)}']);
fprintf(fid, fmt5);
fprintf(fid, hfmt1, '$m$', '$n$', 'mean($p$)');
%fprintf(fid, hfmt2, 'Localized');
fprintf(fid, hfmt3, '','','','','');
fprintf(fid, fmt4);

%rcvrd=100*(resid_init< (1e3*max(min(resid_init,2))));  % successes for resid.
for jj = 1:length(nn)
    ii = find(num_fullcomplete(jj,:));
    %kk = find(num_fullcompletealm(jj,:));
    %fprintf(fid, fmt1, mm(jj), nn(jj), PP(jj));
    fprintf(fid, fmt1, mm(jj), nn(jj), mean(densities(jj,ii)));
    %fprintf(fid, fmt2, mean(num_fullcomplete(jj,:))); ??? need later
    A_str= sprintf('%e\t',mean(resid_init(jj,ii)));
    A_str = strrep(A_str, 'e+0','e+0');
    A_str = strrep(A_str, 'e-0','e-0');
    ALM_str= sprintf('%e\t',mean(resid_initalm(jj,ii)));
    ALM_str = strrep(ALM_str, 'e+0','e+0');
    ALM_str = strrep(ALM_str, 'e-0','e-0');
    fprintf(fid, fmt3, ...
        100*mean(num_fullcomplete(jj,:),2), ...
         100*mean(num_fullcompletealm(jj,:),2), ...
        mean(prerefine_time(jj,ii)), ...  %   mean(prerefine_timealm(jj,kk)),...
       mean(prerefinealm_time(jj,ii)), ...
       mean(rank_init(jj,ii)), ...
        A_str, ALM_str);
    fprintf(fid, fmt4);
end
fprintf(fid, '\\end{tabular}\n');

fclose(fid);

system(['cat ', filename]);
system(['cp ', filename, ' ..\..\latexfiles.d' ]);

end
