function opts = getdata(dataformat)

if strcmp(dataformat,'rand-RPCA-1')
    %%% DATA: from paper by Lin et.al.
    % "Fast convex optimization algorithms for exact recovery of a corrupted low-rank matrix"
    m = 100; n = m; r = round(0.05*m); card = round(0.1*m*n);
    Xs = randn(m,r)*randn(r,n);
    Ys = zeros(m,n);
    tmp = randperm(m*n);
    tmp = tmp(1:card);
    Ys(tmp) = 1000*(rand(card,1)-0.5);
    D = Xs + Ys;
    n1 = m; n2 = n;
    opts.D = D; 
    opts.Xs = Xs; opts.Ys = Ys; opts.mu = norm(D)/1.25;

    %     opts.mu = 1e+1; opts.sigma = 1e-6; opts.rho = 1/sqrt(m); opts.maxitr = 125;
%     opts.eta_mu = 0.25; opts.eta_sigma = 0.25;
%     opts.muf = 1e-6; opts.sigmaf = 1e-6;

elseif strcmp(dataformat,'rand-RPCA-2')
    %%%% Random data: from paper by Candes et.al.
    %                   "Robust PCA? "
    m = 200; n = m; r = round(0.1*n); card = round(0.1*m*n);
    Xs = 1/n * randn(m,r) * randn(r,n);
    Ys = zeros(m,n); tmp = randperm(m*n); tmp = tmp(1:card);
    Ys(tmp) = sign(rand(card,1) - 0.5);
    D = Xs + Ys;
    n1 = m; n2 = n;    
    opts.D = D; 
    opts.Xs = Xs; opts.Ys = Ys; opts.mu = norm(D)/1.25;
    opts.mu = 1e-2;
%     opts.mu = norm(D)/0.5; % opts.mu = norm(D)/1.25;

elseif strcmp(dataformat,'surveillance-video-Lobby')
%     load Lobby_SwitchLight_ALL_1000_2545_1546_128_160.mat;
    load Lobby_SwitchLight_ALL_1000_2545_1546_128_160_gray.mat; 
    [n1,n2] = size(images); % imn1 = 128; imn2 = 160;
    D = images(:,339:588);
    Xs = D; Ys = D;
    opts.D = D; opts.mu = norm(D)/1.25;
        
elseif strcmp(dataformat,'surveillance-video-Hall')
    load Hall_airport_1000_1496_497_144_176_gray.mat;
    D = images(:,1:200); [n1,n2] = size(images); % imn1 = 144; imn2 = 176;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'surveillance-video-Campus')
    load Campus_trees_1000_1993_994_128_160_gray.mat;
%     load Campus_trees_1000_1994_995_128_160_B.mat;
%     load Campus_trees_1000_1995_996_128_160_G.mat;
%     load Campus_trees_1000_1996_997_128_160_R.mat;
    D = images(:,181:500); [n1,n2] = size(D); % imn1 = 128; imn2 = 160;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'surveillance-video-Escalator')
%    load Escalator_airport_1398_2395_998_130_160.mat;
    load Escalator_airport_1398_2394_997_130_160_gray.mat;
    D = images(:,1:300); [n1,n2] = size(images); % imn1 = 130; imn2 = 160;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'surveillance-video-Hall-color')
    load Hall_airport_1000_1495_496_144_176_R.mat; DR = images(:,1:200);
    load Hall_airport_1000_1494_495_144_176_G.mat; DG = images(:,1:200);
    load Hall_airport_1000_1493_494_144_176_B.mat; DB = images(:,1:200);
    D = [DR,DG,DB]; [n1,n2] = size(D); % imn1 = 128; imn2 = 160;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;    
elseif strcmp(dataformat,'surveillance-video-Lobby-color')
    load Lobby_SwitchLight_ALL_1000_2545_1546_128_160_R.mat; DR = images(:,339:588);
    load Lobby_SwitchLight_ALL_1000_2545_1546_128_160_G.mat; DG = images(:,339:588);
    load Lobby_SwitchLight_ALL_1000_2545_1546_128_160_B.mat; DB = images(:,339:588);
    D = [DR,DG,DB]; [n1,n2] = size(D); % imn1 = 128; imn2 = 160;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;   
elseif strcmp(dataformat,'surveillance-video-Campus-color')
    load Campus_trees_1000_1996_997_128_160_R.mat; DR = images(:,181:500);
    load Campus_trees_1000_1995_996_128_160_G.mat; DG = images(:,181:500);
    load Campus_trees_1000_1994_995_128_160_B.mat; DB = images(:,181:500);
    D = [DR,DG,DB]; [n1,n2] = size(D); % imn1 = 128; imn2 = 160;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;    
elseif strcmp(dataformat,'face-recognition')
%     load yaleB01_P00_All.mat; D = images; [n1,n2] = size(images); imn1 = 480; imn2 = 640;
    load yaleB01_P00_x101_300_y251_450.mat;
    D = images; [n1,n2] = size(images); % imn1 = 200; imn2 = 200;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'matrix-completion')
    n1 = 500; 
    rr = 0.01;
    spr = 0.01;
    sr = 0.5; 
    n2 = n1; 
    seed = 94;
  %  rng('default') 
    rng(seed); % NEW
    r = 5;%round(rr*n1);
    m = round(n1*n2*sr);
    spar = round(n1*n2*spr);
    %%%%%%%%%%%%
    P = 4*randn(n1,r);
    %P(abs(P)<1)=P(abs(P)<1)+2;
    Q = 4*randn(r,n2);
    %Q(abs(Q)<1)=Q(abs(Q)<1)+2;
%P = randi(8,m,r);
%Q = randi(8,r,n);
     P = round(P); %% % assume integers data
     Q = round(Q); %% assume integers data
     Lorig = P*Q; % Lorig should be rank r
    %%%%%%%%%
    Xs = Lorig;
    %Xs = randn(n1,r)*randn(r,n2); 
    %%%%%%%%%%%%%%%%%%%%
    inds=find(sprand(n1,n2,sr)); 
    Ys = zeros(n1,n2);
    tmp = randperm(n1*n2); 
    %Omega = tmp(1:m); 
    Omega = inds;
    %Omega_c = tmp(m+1:n1*n2);
    Omega_c = setdiff(1:n1*n2,inds);
    Sorig=spalloc(n1,n2,length(round(spr*inds)));  % D density for sampled els
    temp = 10*sprandn(length(inds),1,spr); % 10 parameter??? for mean error???
    temp(temp<0)=-ceil(-temp(temp<0));
    temp(temp>0)=ceil(temp(temp>0));
    Sorig(inds) = temp; 
    Sorig = full(Sorig);
%%%%%%%%%%%%%%%%
%%%%% lift to nonzero integer values for sparse/outliers
%temp(abs(temp)<1)=sign(temp(abs(temp)<1));
%%%%%%%%%%%%%%%%

    %OmegaY = randperm(n1*n2); 
    %OmegaY = OmegaY(1:spar);
    %Ys(OmegaY) = 1000*(rand(spar,1)-0.5); 
    %Ys(Omega_c) = 0;
    OmegaY= find(Sorig);
    Ys = Sorig;
    D = Xs + Ys; 
    b = D(Omega);
    opts.b = b; 
    opts.OmegaY = OmegaY; 
    opts.Omega_c = Omega_c;
    opts.Omega = Omega;
    opts.mu = norm(b)/1.25;
%     opts.mu = norm(b)*5;
%     beta = m/(sum(abs(b))); beta = 0.2*beta; 
%     beta = 0.25/mean(abs(b)); 
%     opts.mu = 1/beta; 
%     opts.mu = norm(b);
%     opts.mu = 1000;
elseif strcmp(dataformat,'video-denoising')
    load akiyo_data.mat; 
    [n1,n2] = size(akiyo_data);
    spr = round(n1*n2*0.2); picks = randperm(n1*n2); picks = picks(1:spr);
    noise = zeros(n1,n2); noise(picks) = 100*randn(spr,1);
%    noise = 50*randn(n1,n2);
    D = akiyo_data + noise; 
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = akiyo_data; Ys = noise;
elseif strcmp(dataformat, 'video-denoising-color')
    load akiyo_data_color.mat; 
    [n1,n2] = size(akiyo_data_color);
    spr = round(n1*n2*0.2); picks = randperm(n1*n2); picks = picks(1:spr);
    noise = zeros(n1,n2); noise(picks) = 1000*randn(spr,1);
    D = akiyo_data_color + noise;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = akiyo_data_color; Ys = noise;
%     imn1 = 144; imn2 = 176; ind = 100;
%     Dshow = zeros(imn1,imn2,3); Dshow(:,:,1) = reshape(D(:,ind),imn1,imn2);
%     Dshow(:,:,2) = reshape(D(:,ind+300),imn1,imn2); Dshow(:,:,3) = reshape(D(:,ind+600),imn1,imn2);
%     figure; imshow(uint8(Dshow)); 
end

opts.Xs = Xs;  opts.Ys = Ys;
opts.n1 = n1; opts.n2 = n2;
% % opts.mu = norm(D)/1.25;
% opts.mu = norm(b)/1.25;
opts.sigma = 1e-6; opts.maxitr = 100; opts.rho = 1/sqrt(n1); 
opts.eta_mu = 2/3; opts.eta_sigma = 2/3;
% opts.muf = opts.mu*1e-7;
opts.muf = 1e-6;
opts.sigmaf = 1e-6;
opts.epsilon = 1e-7;
opts.sv = 100;
