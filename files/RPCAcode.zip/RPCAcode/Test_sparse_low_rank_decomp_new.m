% clear all; clc;
%randn('state',0); rand('state',0);
% get data 
tic;
% dataformat = 'rand-RPCA-2';
% dataformat = 'surveillance-video-Hall';
% dataformat = 'surveillance-video-Lobby';
% dataformat = 'surveillance-video-Campus';
% dataformat = 'surveillance-video-Escalator';
% dataformat = 'surveillance-video-Hall-color';
% dataformat = 'surveillance-video-Lobby-color';
% dataformat = 'surveillance-video-Campus-color';
% dataformat = 'surveillance-video-Escalator-color';
% dataformat = 'face-recognition';
dataformat = 'matrix-completion';
% dataformat = 'video-denoising';
% dataformat = 'video-denoising-color';
opts = getdata(dataformat); %D = opts.D;
time_getdata = toc;
fprintf('%f seconds to get data ! \n', time_getdata);
% fprintf('size of M: %d, %d\n', size(opts.D));
% return;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Call ALM or FALM to solve the problem
% out_ALM = sparse_low_rank_decomp_ALM(D, opts);
% tic; out_FALM = sparse_low_rank_decomp_FALM(opts.D, opts); time_FALM = toc;
% out_ALM = sparse_low_rank_decomp_ALM_SADAL(D, opts);
% tic; out_ALM = sparse_low_rank_decomp_ALM_SADAL_smoothed(opts.D, opts); time_ALM = toc;
% D = opts.D; tic; out = image_denoise(opts.D,opts); time_denoise = toc;
tic; 
out = ALM_Mat_Comple_v3(opts.b, opts.Omega, opts); time_MC = toc; 
fprintf('*******************************************************************\n');
%%%%%%%%% print stats %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('*******************************************************************\n');
% fprintf('ALM  : iter: %d, relX: %3.2e, relY: %3.2e, StopCrit: %3.2e, time: %f\n', ...
%   out_ALM.iter, out_ALM.relX, out_ALM.relY, out_ALM.StopCrit, time_ALM);
% fprintf('FALM  : iter: %d, relX: %3.2e, relY: %3.2e, StopCrit: %3.2e, time: %f\n', ...
%     out_FALM.iter, out_FALM.relX, out_FALM.relY, out_FALM.StopCrit, time_FALM);
% fprintf('InADM: num_svd: %d, relX: %3.2e, relY: %3.2e, time: %f\n',...
%      num_svd, norm(A-opts.Xs,'fro')/norm(opts.Xs,'fro'),norm(E-opts.Ys,'fro')/norm(opts.Ys,'fro'),time_inADM);
% save all_results_video_denoising_color_20100423.mat;
% fprintf('denoise  : iter: %d, relX: %3.2e, relY: %3.2e, StopCrit: %3.2e, time: %f\n', ...
%       out.iter, out.relX, out.relY, out.StopCrit, time_denoise);
fprintf('MC : iter: %d, relX: %3.2e, relY: %3.2e, StopCrit: %3.2e, time: %f\n', ...
     out.iter, out.relX, out.relY, out.StopCrit, time_MC);
keyboard