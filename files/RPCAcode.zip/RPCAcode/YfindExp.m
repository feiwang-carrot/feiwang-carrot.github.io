function [Yfinal,ZClique,ZsClique,LClique]= YfindExp(Ztemp,Zpart,ZClique,ZsClique,LClique,Lorig,m,n,params,opts,itergrow)
   
r=params.r;   % target rank
verbose=opts.verbose;
%itergrow = opts.itergrow;
%noiselvl = params.noiselevel;
densityS=opts.densityS;
iterlimit = opts.palmlimit;
tolerrank=params.tolerrank;
%density=length(indsZ)/(m*n);
%minsize   = opts.minsize;  % biclique minsize
maxsize   = opts.maxsize;  % biclique maxsize
minclique = params.minclique;
minsize = 2*minclique;
  YTexp = sparse(m,m);
   YSexp = sparse(n,n);
    %nopermuc = 1:n;
    %nopermur = 1:m;
    startgrow=tic;
   % A=[(true(m))   Ztemp
   % Ztemp'     (true(n))];  
   % Imn = eye(m+n);
   % A(Imn==1)=0; 
    % y=GrowCliques(A,maxsize,minsize,nopermur,nopermuc,m,n);
    y = {};
   for ii = 1:itergrow 
    perrow = randperm(m);
    percind = randperm(n);
    %cols = [m+1:m+n];
    %percol = cols(percind);
   % perm = [perrow,percol];
    Ztemps = Ztemp(perrow,percind);
     %Ztemps = Ztemp(perrow,:);
    As=[(true(m))   Ztemps
         Ztemps'     (true(n))];  
     Imn = eye(m+n);
    As(Imn==1)=0;  % set diag to 0
   % As = [speye(m)   sparse(1 - Ztemp)
    %      sparse(1 - Ztemp') speye(n)];
   
  %   keyboard;
    %%%%%%%%%%%%%%%
    %y1=GrowCliques(A,maxsize,minsize);
      ys=GrowCliques(As,maxsize,minsize,perrow,percind,m,n);
      y = [y;ys];       
   end
    clear A As
    numCliques = length(y);
    fprintf('Time for finding %i bicliques   %g \n',...
                    numCliques,toc(startgrow))
    TExpcol = cell(1,numCliques);
    TExprow = cell(1,numCliques);
    TExpval = cell(1,numCliques);
    SExpcol = cell(1,numCliques);
    SExprow = cell(1,numCliques);
    SExpval = cell(1,numCliques);
    %%%% memory allocation %%%%
  
    successS = 0; % sparse exposing vector
    maxc = 0;                       % maxsize of the bicliques
    %ZClique = false(m,n); % used for indicators for sampled bicliques;
    %LClique = sparse(m,n); % data for the low rank part 
    startexpo=tic;
    numsucclow = 0; % number of bicliques where all low rank comp. found
    for ii=1:numCliques     
        indsY=y{ii};
        rowsi=indsY<=m;
        rowsi=indsY(rowsi);
        colsj=indsY>m;
        colsj=indsY(colsj)-m;
        lr=length(rowsi);
        lc=length(colsj);
  if   min(lr,lc)>=minclique% large enough biclique
          lowranksucc = false;
          X=full(Zpart(rowsi,colsj));
	      %SXorig = Sorig(rowsi,colsj);
          LXorig = Lorig(rowsi,colsj);
          if rank(X,tolerrank) == r
              L1 = X;
              [uXtemp,tempsvd,vXtemp]=svd(L1);
              lowranksucc = true;
          else
%%%%use output from Shiqian code here to find L_X
           sk = 1/(lr*lc);
           skmax = max(densityS,sk);
           dsk =  1/(lr*lc);
    while  sk <= skmax + 0.000001&& lowranksucc == false
           %tol = lr*lc*noiselvl;
         %  tol = 1e-12;
            start_PALM=tic;
            [L1,S1] = PALM(X,X,0,r,sk,opts.tolpalm,iterlimit,opts);
	     if  verbose
             time3=toc(start_PALM);
             fprintf('time for file PALM is %g\n',time3)
         end
       %S1 = round(S0);
       %S1 = S0;
      
        L1 = round(L1);
        [uXtemp,tempsvd,vXtemp]=svd(L1);
%        tempsvd=svd(L1);
%       tempsvd
       if abs(tempsvd(r+1,r+1))<lr*lc*opts.tolpalm && norm(S1-round(S1))< 0.5
%        if verbose
%             fprintf('low rank component recovered \n')
%        end
       numsucclow= numsucclow + 1;
       lowranksucc = true;
       end
       sk = sk+ dsk;  % increase sparsity when failure
  
    end   % for the while loop sk = ...
          end
         if (lowranksucc)
            if(opts.noiselevel==0)
             L1 = round(L1);
            end
            if (norm(L1-LXorig)> 10*lr*lc*max(opts.noiselevel,opts.tolrankp))
              fprintf('Original matrix not recovered in YfindExp ,error is %g\n',norm(L1-LXorig));
              %keyboard;
              if(opts.orig ==1)
              L1 = LXorig;
              [uXtemp,tempsvd,vXtemp]=svd(L1);
              end
         %    keyboard;
            end
           % [~,sX,~]=svd(L1);
            diagsX=diag(tempsvd);
            rankX = find(diagsX >= tolerrank*diagsX(1), 1, 'last');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          if rankX < r  % should never happen generically
               fprintf('rankX < r\n');
          %     keyboard
          else  
               
                successS = successS + 1; 
        % finding the largest biclique size 
                maxc = max(maxc,lr+lc);
            % finding row exposing vector
            %     successr=successr+1;  %for testing
                %[uXtemp,~,vXtemp]=svd(L1);
                  temp=uXtemp(:,r+1:lr)*uXtemp(:,r+1:lr)';
	              %temp=(temp+temp')/2;         %no need anymore
  	           %   Yfinal(rowsi,rowsi)= Yfinal(rowsi,rowsi) + temp;    
                  TExpcol{successS} = kron(ones(lr,1),rowsi)';
                  TExprow{successS} = kron(rowsi,ones(lr,1))';
                  TExpval{successS} = temp(:)';
                 % finding col exposing vector
  	       % successc=successc+1;  %for testing    
                   temp=vXtemp(:,r+1:lc)*vXtemp(:,r+1:lc)';
	              %temp=(temp+temp')/2;         %no need anymore
  	             % Yfinal(colsj+m,colsj+m)= Yfinal(colsj+m,colsj+m) + temp;
                  SExpcol{successS} = kron(ones(lc,1),colsj)';
                  SExprow{successS} = kron(colsj,ones(lc,1))';
                  SExpval{successS} = temp(:)';
              %%%%%%%%%%%%%%%%%%% forming the matrix of elements from all
              %%%%%%%%%%%%%%%%%%% the bicliques
              ZClique(rowsi,colsj) = 1;   % indices are bicliques
              ZsClique(rowsi,colsj) = 1;  % indices are recovered
              LClique(rowsi,colsj) = L1;  % data for the biclique above
  %%%%%%%%%%%%LClique(Zclique)=Zorig(Zclique)-Sorig(Zclique)=Lorig(Zcclique);
         %%%%%%%%
          end   % end for the if: check on rankX >=r
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         end
  end
    %keyboard;
    end
    clear y
   
     fprintf('Time for constructing exposing vector %g \n',...
                    toc(startexpo))
    fprintf('maxc =  %i; and  %i successful  bicliques, resp.  \n',...
                        maxc,successS);
  %keyboard
  %Yfinal(abs(Yfinal)<1e-12)=0;      % change??? only needed for eigs???
   YTexp = YTexp + sparse(cell2mat(TExpcol),cell2mat(TExprow),cell2mat(TExpval),m,m);
   YTexp = (YTexp + YTexp')/2;
   YSexp = YSexp + sparse(cell2mat(SExpcol),cell2mat(SExprow),cell2mat(SExpval),n,n);
   YSexp = (YSexp + YSexp')/2;
   Yfinal = [YTexp, sparse(m,n)
             sparse(n,m) YSexp];   
  %Yfinal=(Yfinal+Yfinal')/2;
  %Yfinal=sparse(Yfinal);
  
  fprintf('density of Yfinal:  %g;  \n',nnz(Yfinal)/numel(Yfinal));
 end