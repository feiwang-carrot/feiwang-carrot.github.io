--------------------------------------------------
Three papers from Shiqian: on the robust PCA problem. The RobustPCA
paper is about the background theory. The StableRPCA paper talks about the
noisy version. The FALM paper discusses an alternating direction type method
for solving this problem and a a matlab code
here: http://www1.se.cuhk.edu.hk/~sqma/ALM-RPCA.html [www1.se.cuhk.edu.hk] .

----------------
Add all folders and subfolders to your current matlab path.

run tablenoiseless.m to compare facial reduction method with ALM method (Shiqian Ma's papers) on the noiseless case
run tablenoise.m  to compare with ALM method (Shiqian Ma's papers) on the noise case

These files will run Rrun_testnoiseless.m and  Rrun_testnoise.m and generate latex tables.

You can change the parameters in tablenoiseless.m and tablenoise.m .